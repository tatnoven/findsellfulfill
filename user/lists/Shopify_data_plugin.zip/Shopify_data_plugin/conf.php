<?php
 	define('SHOPIFY_APP_API_KEY', '');
	define('SHOPIFY_APP_SHARED_SECRET', '');
	define('REDIRECT_URI', 'https://www.productmafia.com/wp-content/plugins/Shopify_data_plugin/oauth.php'); 
?>